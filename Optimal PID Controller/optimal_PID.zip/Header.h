#pragma once

void train(void);
void show(void);
void load(void);

float dR(const float&, const float&);
float dL(const float&, const float&);